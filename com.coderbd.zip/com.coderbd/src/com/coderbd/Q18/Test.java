
package com.coderbd.Q18;
public class Test {
    //Theory
}
