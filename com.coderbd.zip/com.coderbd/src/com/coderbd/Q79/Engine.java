
package com.coderbd.Q79;

 class Engine {
     double fuelLevel;
     Engine(int fuelLevel){
         this.fuelLevel=fuelLevel;
     }
     public void start(){
         // Line n1
         assert fuielLevel < 0 : System.exit(0);
         System.out.println("Started");
     }
     public void stop(){
         System.out.println("Stopped");
     }
     public static void main(String[] args) {
         
     }
    // Ans: Confuse
}
