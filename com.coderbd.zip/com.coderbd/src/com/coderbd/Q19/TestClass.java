
package com.coderbd.Q19;
class Foo{
    public void methodB
}
public class TestClass {
    
}
