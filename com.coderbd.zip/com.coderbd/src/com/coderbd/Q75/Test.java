package com.coderbd.Q75;

import java.io.Console;

public class Test {
    public static void main(String[] args) {
        Console console = System.console();
        char[] pass =console.readLine("Enter password:");  //line n1
        String password =new String(pass);
        String Password =new String(pass);   //line n2
        
    }
   // Ans: B
}
