
package pkg809;

/**
 * Question 48
 * @Answer: ?
 */
public class Book {
    private int id;
    private String name;
    public Book(int id) {this.id = id;}
    public Book(int id, String name){this.id; this.name = name}
    public int getId() {return id;}
    public String getName(){return name;}
    public void setIdI(int id){this.id = id;}
    public void setName(String name){this.name = name}
}
