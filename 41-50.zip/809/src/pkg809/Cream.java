
package pkg809;

/**
 * Question 47
 * @Answer: ?
 */
public class Cream {
    public void prepare(){}
}

public class Cake extends Cream{
    public void bake(int min, int temp){}
    public void mix(){ }
}

public class Bread extends Cake{
    public void bake(int minutes, int temperature){}
    public void addToppings(){}
}