
package pkg809;

/**
 * Question 44
 * @Answer: ?
 */
public class ProductCode(T, String S) {
    T c1;
    S c2;
}

